plugins { id("com.android.application") }

android {
    namespace = "pt.radioportugal.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "pt.radioportugal.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 3
        versionName = "3.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    val media3 = "1.11.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-session:$media3")
    implementation("androidx.webkit:webkit:1.17.1")
    implementation("com.google.guava:guava:33.4.8-android")
}
