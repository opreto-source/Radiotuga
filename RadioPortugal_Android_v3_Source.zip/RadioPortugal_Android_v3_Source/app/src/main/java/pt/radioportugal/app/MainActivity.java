package pt.radioportugal.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.webkit.WebViewAssetLoader;
import com.google.common.util.concurrent.ListenableFuture;

import org.json.JSONObject;

/** App shell do site v3; Media3 gere streams e áudio em segundo plano. */
public class MainActivity extends Activity {
    private WebView web;
    private ListenableFuture<MediaController> controllerFuture;
    private MediaController controller;
    private String activeToken = "";
    private String activeUrl = "";
    private Runnable pendingCommand;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.getSettings().setSupportMultipleWindows(false);
        web.setWebChromeClient(new WebChromeClient());
        // A bridge só é exposta à página local de confiança, nunca a websites externos.
        web.addJavascriptInterface(new RadioBridge(), "NativeRadio");
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String uri = request.getUrl().toString();
                if (uri.startsWith("https://appassets.androidplatform.net/assets/")) return false;
                if (request.isForMainFrame()) openExternal(uri);
                return true;
            }
        });
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        startController();
    }

    private void startController() {
        SessionToken token = new SessionToken(this, new ComponentName(this, PlaybackService.class));
        controllerFuture = new MediaController.Builder(this, token).buildAsync();
        controllerFuture.addListener(() -> {
            try {
                controller = controllerFuture.get();
                controller.addListener(new Player.Listener() {
                    @Override public void onIsPlayingChanged(boolean playing) {
                        if (playing) notifyJs("playing");
                    }
                    @Override public void onPlaybackStateChanged(int state) {
                        if (state == Player.STATE_BUFFERING) notifyJs("buffering");
                        if (state == Player.STATE_READY && controller.isPlaying()) notifyJs("playing");
                    }
                    @Override public void onPlayerError(PlaybackException error) { notifyJs("error"); }
                    @Override public void onPlayWhenReadyChanged(boolean playWhenReady, int reason) {
                        if (!playWhenReady && controller.getPlaybackState() == Player.STATE_READY) notifyJs("paused");
                    }
                });
                if (pendingCommand != null) {
                    Runnable todo = pendingCommand;
                    pendingCommand = null;
                    todo.run();
                }
            } catch (Exception e) {
                notifyJs("error");
            }
        }, this::runOnUiThread);
    }

    private void withController(Runnable command) {
        if (controller != null) command.run();
        else pendingCommand = command;
    }

    private void notifyJs(String event) {
        if (web == null || activeUrl.isEmpty()) return;
        String js = "window.radioNativeEvent && window.radioNativeEvent(" +
                JSONObject.quote(event) + "," + JSONObject.quote(activeToken) + "," +
                JSONObject.quote(activeUrl) + ");";
        web.evaluateJavascript(js, null);
    }

    private void openExternal(String url) {
        Uri uri = Uri.parse(url);
        if (!"https".equalsIgnoreCase(uri.getScheme())) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (Exception ignored) { }
    }

    private class RadioBridge {
        @JavascriptInterface public void play(String url, String name, String token) {
            runOnUiThread(() -> {
                if (!url.startsWith("https://")) { notifyJs("error"); return; }
                activeUrl = url;
                activeToken = token;
                withController(() -> {
                    MediaMetadata metadata = new MediaMetadata.Builder()
                            .setTitle(name).setArtist("Rádio Portugal · Em direto").build();
                    MediaItem item = new MediaItem.Builder().setUri(Uri.parse(url))
                            .setMediaMetadata(metadata).build();
                    controller.setMediaItem(item);
                    controller.prepare();
                    controller.play();
                });
            });
        }
        @JavascriptInterface public void resume() {
            runOnUiThread(() -> withController(() -> controller.play()));
        }
        @JavascriptInterface public void pause() {
            runOnUiThread(() -> withController(() -> controller.pause()));
        }
        @JavascriptInterface public void stop() {
            runOnUiThread(() -> withController(() -> controller.stop()));
        }
        @JavascriptInterface public void openExternal(String url) {
            runOnUiThread(() -> MainActivity.this.openExternal(url));
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (controllerFuture != null) MediaController.releaseFuture(controllerFuture);
        controller = null;
        if (web != null) {
            web.removeJavascriptInterface("NativeRadio");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
