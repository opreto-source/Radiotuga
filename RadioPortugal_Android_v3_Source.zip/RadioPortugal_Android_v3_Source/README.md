# Rádio Portugal v3 — código-fonte para APK Android

Este ficheiro contém **a versão 3 do website** (incluindo rádios alentejanas, regiões, distritos, pesquisa, favoritas e Radio Browser) integrada numa aplicação Android Java, com um player **Media3/ExoPlayer** e sessão de media para continuar a ouvir em segundo plano.

## Para compilar

1. Abrir esta pasta inteira no **Android Studio** (não abrir apenas o HTML).
2. Instalar Android SDK Platform 35, JDK 17 e sincronizar Gradle. AGP 8.9.2 requer Gradle 8.11.1 ou superior; foi configurado Gradle 8.13.
3. Usar **Build → Build Bundle(s) / APK(s) → Build APK(s)** ou `./gradlew assembleDebug`.
4. Resultado esperado: `app/build/outputs/apk/debug/app-debug.apk`.
5. Instalar o APK no telemóvel (Android 7.0+ / API 24+). A primeira compilação precisa de Internet.

**AVISO sobre Gradle**: este ZIP contém um script de bootstrap `gradlew` que descarrega Gradle 8.13; não contém o `gradle-wrapper.jar` habitual. Se o Android Studio não importar corretamente, um ambiente com Gradle instalado deve executar `gradle wrapper --gradle-version 8.13` para gerar o wrapper standard. Alternativamente configurar Gradle 8.13 no IDE.

## Estrutura

- `app/src/main/assets/index.html`: versão v3 com interface e filtros **e integração opcional `NativeRadio`**. No Android usa Media3; no navegador, o HTML original funciona com `<audio>`.
- `Web_v3_Original.html`: cópia exata da versão web v3 anterior, para comparação e publicação web.
- `app/src/main/java/pt/radioportugal/app/MainActivity.java`: WebViewAssetLoader, controlos e ponte para o leitor nativo.
- `app/src/main/java/pt/radioportugal/app/PlaybackService.java`: MediaSessionService + ExoPlayer, áudio no ecrã bloqueado.
- `app/src/main/AndroidManifest.xml`: permissões Internet, media playback e foreground service.

## Importante para a IA que compila

- **Não substituir a lista do Alentejo pela lista antiga de rádios nacionais.** O HTML completo v3 está em `app/src/main/assets/index.html`.
- Verificar que a compilação corre sem erros de Gradle/Java, testar o APK num dispositivo Android com pelo menos Android 7.
- Testar Rádio Comercial, Antena 1, Diana FM, Rádio Pax, Rádio Campanário e Rádio Portalegre, incluindo fontes alternativas, conexão Wi-Fi/dados móveis, bloqueio do ecrã e notificações. Algumas emissoras têm apenas página de acesso e não stream confirmado. Não apresentar todas as rádios como verificadas ao vivo.
- Verificar que os botões **Pausar / Reproduzir**, favoritos e filtros mantêm o estado depois de fechar e reabrir a app. `localStorage` do `appassets.androidplatform.net` **não é o mesmo** `localStorage` do site Netlify: favoritas da versão web não são importadas automaticamente.
- Testar com e sem VPN; falhas geográficas/servidores fora de serviço não são contornáveis apenas com o player.
- Antes de distribuir publicamente, verificar regras de marcas, stream e Play Store.

## Limitações de verificação

O código-fonte foi montado e validado quanto ao JavaScript e XML, mas **não foi compilado num ambiente Android SDK**, pelo que pequenos ajustes podem ser necessários na outra IA/Android Studio. Este ZIP **não é um APK**.
