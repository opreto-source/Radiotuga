@echo off
setlocal
set "GRADLE_VERSION=8.13"
set "ROOT=%~dp0"
set "CACHE=%USERPROFILE%\.gradle\radio-portugal-bootstrap"
set "BIN=%CACHE%\gradle-%GRADLE_VERSION%\bin\gradle.bat"
if not exist "%BIN%" (
    echo A obter Gradle %GRADLE_VERSION% da distribuicao oficial...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $d='%CACHE%'; New-Item -Force -ItemType Directory $d | Out-Null; $z=Join-Path $d 'gradle-%GRADLE_VERSION%-bin.zip'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile $z; Expand-Archive -Force -Path $z -DestinationPath $d; Remove-Item $z"
    if errorlevel 1 exit /b 1
)
call "%BIN%" %*
exit /b %ERRORLEVEL%
